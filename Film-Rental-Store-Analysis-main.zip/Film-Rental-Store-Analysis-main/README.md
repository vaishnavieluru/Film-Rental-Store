# Film-Rental-Store-Analysis
SQL data analysis of Film Rental Store Data

MySQL data analysis project in helping Film Rental Store to perform data analysis for 
1. user behaviours 
2. discover marketing stats
3. find actionable customer/business insights
4. measure and track marketing efforts
